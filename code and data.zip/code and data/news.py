
# import tkinter as tk
# from tkinter import messagebox
# import joblib

# # Load the model and vectorizer
# model = joblib.load('Logistic_model.pkl')
# tfidf_vectorizer = joblib.load('tfidf_vectorizer.pkl')

# def classify_news():
#     input_text = text_entry.get("1.0", tk.END).strip()
#     if input_text:
#         text_tfidf = tfidf_vectorizer.transform([input_text])
#         prediction = model.predict(text_tfidf)
#         category_label.config(text=f"Category: {prediction[0]}")
#     else:
#         messagebox.showwarning("Input Error", "Please enter some text to classify.")

# # Create the main application window
# root = tk.Tk()
# root.title("News Classification")

# # Set window size and background color
# root.geometry("600x400")
# root.configure(bg="#f0f0f0")

# # Create and place the text entry widget
# tk.Label(root, text="Enter news text here:", font=("Helvetica", 14), bg="#f0f0f0").pack(pady=10)
# text_entry = tk.Text(root, height=10, width=60, font=("Helvetica", 12), wrap="word", borderwidth=2, relief="groove")
# text_entry.pack(pady=10, padx=10)

# # Create and place the classify button
# classify_button = tk.Button(root, text="Classify", font=("Helvetica", 14), bg="#4CAF50", fg="white", command=classify_news)
# classify_button.pack(pady=10)

# # Create and place the label for displaying the classification result
# category_label = tk.Label(root, text="Category: ", font=("Helvetica", 14), bg="#f0f0f0")
# category_label.pack(pady=10)

# # Add padding around all widgets
# for widget in root.winfo_children():
#     widget.pack_configure(padx=10, pady=5)

# # Start the Tkinter event loop
# root.mainloop()

 

import tkinter as tk
from tkinter import messagebox
import joblib

# Load the model and vectorizer
model = joblib.load('Logistic_model.pkl')
tfidf_vectorizer = joblib.load('tfidf_vectorizer.pkl')

# Define the category mapping
category_mapping = {
    0: "business",
    1: "entertainment",
    2: "politics",
    3: "sport",
    4: "tech"
}

def classify_news():
    input_text = text_entry.get("1.0", tk.END).strip()
    if input_text:
        text_tfidf = tfidf_vectorizer.transform([input_text])
        prediction = model.predict(text_tfidf)[0]
        category_name = category_mapping.get(prediction, "Unknown")
        category_label.config(text=f"Category: {category_name}", fg="#0000FF")
    else:
        messagebox.showwarning("Input Error", "Please enter some text to classify.")

# Create the main application window
root = tk.Tk()
root.title("News Classification")

# Set window size and background color
root.geometry("700x500")
root.configure(bg="#2e3f4f")

# Create and place the title label
title_label = tk.Label(root, text="News Classification App", font=("Helvetica", 24, "bold"), bg="#2e3f4f", fg="#FFFFFF")
title_label.pack(pady=20)

# Create and place the text entry label and widget
entry_label = tk.Label(root, text="Enter news text here:", font=("Helvetica", 14), bg="#2e3f4f", fg="#FFFFFF")
entry_label.pack(pady=10)
text_entry = tk.Text(root, height=10, width=60, font=("Helvetica", 12), wrap="word", borderwidth=2, relief="groove")
text_entry.pack(pady=10, padx=10)

# Create and place the classify button
classify_button = tk.Button(root, text="Classify", font=("Helvetica", 14), bg="#4CAF50", fg="white", command=classify_news)
classify_button.pack(pady=10)

# Create and place the label for displaying the classification result
category_label = tk.Label(root, text="Category: ", font=("Helvetica", 14), bg="#2e3f4f", fg="#FFFFFF")
category_label.pack(pady=10)

# Add padding around all widgets
for widget in root.winfo_children():
    widget.pack_configure(padx=20, pady=5)

# Start the Tkinter event loop
root.mainloop()


